const express = require('express');  
const bodyParser = require('body-parser');  
const cors = require('cors');  
const app = express();  
  
// 设置静态文件目录  
app.use(cors());  
app.use(bodyParser.json()); // 支持JSON编码的请求体  
app.use(bodyParser.urlencoded({ extended: true })); // 支持URL编码的请求体  
  
// 设置端口  
const PORT = process.env.PORT || 3000;  
app.listen(PORT, () => {  
    console.log(`Server is running on port ${PORT}`);  
});  

const connection = require('./db');  
  
  //Retrieve fundraising activities for all events, including categories
app.get('/fundraiser', (req, res) => {  
        connection.query(  
            `SELECT f.*, t.NAME AS CATEGORY_NAME  
            FROM fund_raiser f  
            LEFT JOIN category t ON f.CATEGORY_ID = t.CATEGORY_ID;`  
        ,(err, results) => {
        	res.json(results);  
        });  
});

//Retrieve all categories
app.get('/categories',  (req, res) => {  
        connection.query(`SELECT * FROM category;`,(err, results) => {  
			res.json(results);  
		});  
});

//Retrieve fundraisers for all category based activities
app.get('/category/:categoryId', (req, res) => {  
    const { categoryId } = req.params;  
        connection.query(  
            `SELECT f.*, t.NAME AS CATEGORY_NAME  
            FROM fund_raiser f  
            LEFT JOIN category t ON f.CATEGORY_ID = t.CATEGORY_ID  
            WHERE f.FUNDRAISER_ID = ?;`,  
            [categoryId],(err,results) => {  
				res.json(results);  
    });
}); 

//Retrieve detailed information of fundraisers by ID
app.get('/fundraisers/:fundraiserId', (req, res) => {  
    const { fundraiserId } = req.params;  
        connection.query(  
            `SELECT f.*, t.NAME AS CATEGORY_NAME  
            FROM fund_raiser f  
            LEFT JOIN category t ON f.CATEGORY_ID = t.CATEGORY_ID  
            WHERE f.FUNDRAISER_ID = ?;`,  
            [fundraiserId],(err,results) => {  
				res.json(results);  
    });
});

//Multi criteria search function based on organizer, city, and category
app.get('/search', (req, res) => {  
    const { organizer, city, categoryId } = req.query;
	  console.log(req.query)
    let sql = `SELECT f.*, t.NAME AS CATEGORY_NAME  
               FROM fund_raiser f  
               LEFT JOIN category t ON f.CATEGORY_ID = t.CATEGORY_ID WHERE f.ACTIVITY='active'`;  
			   
    let params = [];  
    let conditions = [];  
  
    if (organizer != 'undefined') {  
        conditions.push(`f.ORGANIZER LIKE '${organizer}'`);  
        params.push(`%${organizer}%`);  
    }  
  
    if (city != 'undefined') {  
        conditions.push(`f.CITY LIKE '${city}'`);  
        params.push(`%${city}%`);  
    }  
  
    if (categoryId != 'undefined') {  
        conditions.push(`f.CATEGORY_ID = '${categoryId}'`);  
        params.push(categoryId);  
    }  
  
    sql += `AND ${conditions.join(' AND ')}`;  
	console.log(sql)
    connection.query(sql, params, (err, results) => {  
        res.json(results);  
    });
});

// POST route to insert a new donation for a specified fundraiser  
app.post('/donation', (req, res) => {  
    const { fundraiserId,amount, giver } = req.body;  
    //Building SQL queries and parameter arrays
    const sql = 'INSERT INTO donation (AMOUNT, GIVER, FUNDRAISER_ID) VALUES (?, ?, ?)';  
    const params = [amount, giver, fundraiserId];  
  
    //Execute SQL query
    connection.query(sql, params, (err, results) => {
        res.json(results);  
    });
});

app.post('/add_fundraiser', (req, res) => {  
    const {  
        TARGET_FUNDING,  
        GURRENT_FUNDING, 
        CITY,  
        CATEGORY_ID,  
        ORGANIZER,  
        TITLE,  
        ACTIVITY 
    } = req.body;
	const query = `INSERT INTO fund_raiser values(null,'${TARGET_FUNDING}','${GURRENT_FUNDING}','${CITY}','${CATEGORY_ID}','${ORGANIZER}','${TITLE}','${ACTIVITY}')`;
	//Execute SQL query
    connection.query(query, null, (err, results) => {  
		 res.json(results);  
    });  
});

app.put('/update_fundraisers/:id', (req, res) => {  
    const { id } = req.params;  
    const updates = req.body;
	const newObject = {  
	  title: updates.title,  
	  organizer: updates.organizer,  
	  city: updates.city,  
	  targetFunding: updates['target-funding'], //Accessing key names with quotation marks using square bracket syntax
	  currentFunding: updates['current-funding'],  
	  categoryId: updates['category-id'],  
	  status: updates.status  
	};
	console.log(newObject)
	const query = `UPDATE fund_raiser SET TITLE='${newObject.title}',ORGANIZER='${newObject.organizer}',CITY='${newObject.city}',TARGET_FUNDING='${newObject.targetFunding}',GURRENT_FUNDING='${newObject.currentFunding}',CATEGORY_ID='${newObject.categoryId}',ACTIVITY='${newObject.status}' WHERE FUNDRAISER_ID = '${id}'`;
	//Execute SQL query
    connection.query(query, null, (err, results) => {  
       res.json(results);  
    });  
});

app.delete('/deleted_fundraisers/:id', (req, res) => {  
    const { id } = req.params;  
  
    const checkDonationsQuery = 'SELECT COUNT(*) AS count FROM donation WHERE FUNDRAISER_ID = ?'; 
    connection.query(checkDonationsQuery, [id], (err, checkResults) => {  
       
        if (checkResults[0].count > 0) {  
            return res.status(409).json({ error: 'Cannot delete fundraiser with donations' });  
        }  
  
        //If there is no donation, delete the fundraising event  
        const deleteQuery = 'DELETE FROM fund_raiser WHERE FUNDRAISER_ID = ?';  
		//Execute SQL query
        connection.query(deleteQuery, [id], (err, deleteResults) => {  
            res.json(deleteResults);  
        });  
    });  
});